package aes

import (
	"encoding/json"
	"io"
	// "github.com/sanity-io/litter"
)

type EncryptedData struct {
	Hash string `json:"hash"`
	Salt string `json:"salt"`
	Key  string `json:"-"`
	pos  int
}

func (e EncryptedData) Decrypt() string {
	if e.Hash == "" && e.Salt == "" {
		return ""
	}

	result, _ := Decrypt(e.Key, e.Hash, e.Salt)
	return result
}

func (e EncryptedData) Read(p []byte) (n int, err error) {
	data, err := json.Marshal(e)
	if e.pos >= len(data) {
		return 0, io.EOF
	}

	n = copy(p, data[e.pos:])
	e.pos += n

	return n, nil
}
