package aes

import (
	"encoding/json"
	"io"
	"os"
	"strings"

	"github.com/simiancreative/simiango/cryptkeeper/keepers"
)

type Keeper struct {
	hash string
	salt string
	key  string
}

func (p Keeper) Setup(input ...any) keepers.Keeper {
	if len(input) == 0 {
		return nil
	}

	keyName, ok := input[0].(string)
	if !ok {
		return nil
	}

	p.key = os.Getenv(keyName)

	return p
}

func (p Keeper) Encrypt(content io.Reader) (io.Reader, error) {
	value, err := io.ReadAll(content)
	if err != nil {
		return nil, err
	}

	return Encrypt(p.key, string(value))
}

func (p Keeper) Decrypt(content io.Reader) (io.Reader, error) {
	value, err := io.ReadAll(content)
	if err != nil {
		return nil, err
	}

	dest := EncryptedData{}
	err = json.Unmarshal(value, &dest)
	if err != nil {
		return nil, err
	}

	result, err := Decrypt(p.key, dest.Hash, dest.Salt)
	if err != nil {
		return nil, err
	}

	reader := strings.NewReader(result)

	return reader, nil
}

func New() keepers.Keeper {
	return Keeper{}
}
