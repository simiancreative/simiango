package aes

type DecryptableData struct {
	Key  string `json:"-"`
	Hash string `json:"hash"`
	Salt string `json:"salt"`
}

func (e DecryptableData) Decrypt() string {
	if e.Key == "" || e.Hash == "" || e.Salt == "" {
		return ""
	}

	result, _ := Decrypt(e.Key, e.Hash, e.Salt)
	return result
}
