package aes

import (
	"database/sql/driver"
	"encoding/json"

	// "github.com/sanity-io/litter"
	"reflect"
)

type EncryptedContainer map[string]EncryptedData

func (dst EncryptedContainer) Value() (driver.Value, error) {
	return json.Marshal(dst)
}

func (dst *EncryptedContainer) UnmarshalJSON(b []byte) error {
	c := EncryptedContainer{}
	src := map[string]string{}
	json.Unmarshal(b, &src)

	keys := reflect.ValueOf(src).MapKeys()
	for _, key := range keys {
		e := src[key.String()]
		val, _ := Encrypt("", e)
		c[key.String()] = val
	}

	*dst = c

	return nil
}
