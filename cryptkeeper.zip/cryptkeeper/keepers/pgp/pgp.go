package pgp

import (
	"encoding/base64"
	"errors"
	"io"
	"os"
	"strings"

	"github.com/ProtonMail/gopenpgp/v2/helper"
	"github.com/simiancreative/simiango/cryptkeeper/keepers"
)

type Keeper struct {
	privateKey string
	publicKey  string
	passphrase string
}

func (p Keeper) Setup(input ...any) keepers.Keeper {
	if len(input) == 0 {
		return nil
	}

	varPrefix, ok := input[0].(string)
	if !ok {
		return nil
	}

	// load keys and passphrase from env vars
	p.privateKey = os.Getenv(strings.ToUpper(varPrefix) + "_PRIVATE_KEY")
	p.passphrase = os.Getenv(strings.ToUpper(varPrefix) + "_PASSPHRASE")
	p.publicKey = os.Getenv(strings.ToUpper(varPrefix) + "_PUBLIC_KEY")

	return p
}

func (p Keeper) Decrypt(file io.Reader) (io.Reader, error) {
	content, err := io.ReadAll(file)
	if err != nil {
		return file, err
	}

	privateKey, _ := base64.StdEncoding.DecodeString(p.privateKey)

	decrypted, err := helper.DecryptMessageArmored(
		string(privateKey),
		[]byte(p.passphrase),
		string(content),
	)

	if err != nil {
		return file, err
	}

	return strings.NewReader(decrypted), nil
}

func (p Keeper) Encrypt(reader io.Reader) (io.Reader, error) {
	return nil, errors.New("not implemented")
}

func New() keepers.Keeper {
	return Keeper{}
}
