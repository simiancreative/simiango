package keepers

import (
	"io"
)

type Keeper interface {
	Setup(input ...any) Keeper
	Decrypt(content io.Reader) (io.Reader, error)
	Encrypt(content io.Reader) (io.Reader, error)
}

var keepers map[string]func() Keeper

func Register(n string, k func() Keeper) {
	keepers[n] = k
}

func NewKeeper(kind string) (Keeper, error) {
	keeper, ok := keepers[kind]
	if !ok {
		return nil, NotFoundError(kind)
	}

	return keeper(), nil
}
