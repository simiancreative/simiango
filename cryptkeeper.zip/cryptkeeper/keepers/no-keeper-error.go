package keepers

import (
	_ "embed"

	"fmt"
	"strings"
)

//go:embed no-keeper-error.txt
var notFoundTxt string

func NotFoundError(kind string) error {
	return NotFound{kind: kind}
}

type NotFound struct {
	kind string
}

func (e NotFound) Error() string {
	return fmt.Sprintf(notFoundTxt, e.kind, availableKeepers())
}

func availableKeepers() string {
	keys := []string{""}

	for k := range keepers {
		keys = append(keys, fmt.Sprintf("✅ %v", k))
	}

	return strings.Join(keys, "\n  ")
}
