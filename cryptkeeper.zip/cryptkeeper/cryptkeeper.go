package cryptkeeper

import (
	"github.com/simiancreative/simiango/cryptkeeper/keepers"

	"github.com/simiancreative/simiango/cryptkeeper/keepers/aes"
	"github.com/simiancreative/simiango/cryptkeeper/keepers/pgp"
)

func init() {
	keepers.Register("AES", aes.New)
	keepers.Register("PGP", pgp.New)
}

var New = keepers.NewKeeper
